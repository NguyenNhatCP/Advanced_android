package com.example.appnews.model;

import com.example.appnews.model.User;

public class Common {
    public static User currentUser;

    public static String Phone_Key = "Phone";
    public static String PassWord_Key = "Password";
}
