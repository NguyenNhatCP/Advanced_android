package com.example.kiemtragk;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.kiemtragk.adapter.CustomAdapter;
import com.example.kiemtragk.data.SQLiteHelper;
import com.example.kiemtragk.model.Product;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText edtId;
    private EditText edtName;
    private EditText edtMDF_Date;
    private EditText editAddress;
    private EditText edtEXP_Date;
    private EditText edtImage;
    private EditText edtPrice;
    private Button btnAdd;
    private Button btnDelete;
    private Button btnUpdate;
    private ListView lstproduct;
    private SQLiteHelper db;
    private CustomAdapter customAdapter;
    private List<Product> productList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new SQLiteHelper(this);
        AddEvent();
        productList = db.getAllProduct();
        setAdapter();
        lstproduct.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Product product = productList.get(position);
                edtId.setText(String.valueOf(product.getID()));
                edtName.setText(product.getTenSP());
                edtMDF_Date.setText(product.getNgaySX());
                editAddress.setText(product.getNoiSX());
                edtEXP_Date.setText(product.getNgayHH());
                edtImage.setText(product.getHinhSP());
                edtPrice.setText(String.valueOf(product.getGia()));
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Product product = createProduct();
                if(product != null)
                {
                    db.addProduct(product);
                }
                updateListProduct();
                setAdapter();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Product product = new Product();
                product.setID(Integer.parseInt(String.valueOf(edtId.getText())));
                product.setTenSP(edtName.getText()+"");
                product.setNgaySX(edtMDF_Date.getText()+"");
                product.setNoiSX(editAddress.getText()+"");
                product.setNgayHH(edtEXP_Date.getText()+"");
                product.setHinhSP(edtImage.getText()+"");
                product.setGia(Integer.parseInt(edtPrice.getText()+""));
                int result = db.updateProduct(product);
                if(result>0){
                    updateListProduct();
                }
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int result = db.deleteProduct(Integer.parseInt(edtId.getText().toString()));
                if(result>0){
                    Toast.makeText(MainActivity.this, "Delete successfuly", Toast.LENGTH_SHORT).show();
                    updateListProduct();
                }else{
                    Toast.makeText(MainActivity.this, "Delete fail", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private  void AddEvent()
    {
        edtId = (EditText) findViewById(R.id.edt_id);
        edtName = (EditText) findViewById(R.id.edt_name);
        edtMDF_Date = (EditText) findViewById(R.id.edt_mdfDate);
        editAddress = (EditText) findViewById(R.id.edt_address);
        edtEXP_Date = (EditText) findViewById(R.id.edt_expDate);
        edtImage = (EditText) findViewById(R.id.edt_Image);
        edtPrice = (EditText) findViewById(R.id.edt_price);
        btnAdd = (Button) findViewById(R.id.btn_add);
        lstproduct = (ListView) findViewById(R.id.lv_product);
        btnUpdate = (Button) findViewById(R.id.btn_update);
        btnDelete = (Button)findViewById(R.id.btn_delete);
    }
    private void setAdapter() {
        if (customAdapter == null) {
            customAdapter = new CustomAdapter(this, R.layout.item_product, productList);
            lstproduct.setAdapter(customAdapter);
        }else{
            //Cập nhật lại
            customAdapter.notifyDataSetChanged();
            lstproduct.setSelection(customAdapter.getCount()-1);
        }
    }
    private Product createProduct() {
        String name = edtName.getText().toString();
        String mdf_date = edtMDF_Date.getText().toString();
        String address = String.valueOf(editAddress.getText());
        String exp_date = edtEXP_Date.getText().toString();
        String hinh = edtImage.getText().toString();
        String gia = edtPrice.getText().toString();

        Product product = new Product(name, mdf_date, address, exp_date,hinh,Integer.parseInt(gia));
        return product;
    }
    public void updateListProduct(){
        productList.clear();
        productList.addAll(db.getAllProduct());
        if(customAdapter!= null){
            customAdapter.notifyDataSetChanged();
        }
    }
}
