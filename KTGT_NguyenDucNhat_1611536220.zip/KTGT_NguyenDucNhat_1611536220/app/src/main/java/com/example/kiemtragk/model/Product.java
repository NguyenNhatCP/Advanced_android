package com.example.kiemtragk.model;


public class Product {
    public  int ID;
    public String tenSP;
    public String ngaySX;
    public  String noiSX;
    public  String ngayHH;
    public  String hinhSP;
    public int Gia;

    public Product() {
    }

    public Product(String tenSP, String ngaySX, String noiSX, String ngayHH, String hinhSP, int gia) {
        this.tenSP = tenSP;
        this.ngaySX = ngaySX;
        this.noiSX = noiSX;
        this.ngayHH = ngayHH;
        this.hinhSP = hinhSP;
        this.Gia = gia;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getNgaySX() {
        return ngaySX;
    }

    public void setNgaySX(String ngaySX) {
        this.ngaySX = ngaySX;
    }

    public String getNoiSX() {
        return noiSX;
    }

    public void setNoiSX(String noiSX) {
        this.noiSX = noiSX;
    }

    public String getNgayHH() {
        return ngayHH;
    }

    public void setNgayHH(String ngayHH) {
        this.ngayHH = ngayHH;
    }

    public String getHinhSP() {
        return hinhSP;
    }

    public void setHinhSP(String hinhSP) {
        this.hinhSP = hinhSP;
    }

    public int getGia() {
        return Gia;
    }

    public void setGia(int gia) {
        Gia = gia;
    }
}
