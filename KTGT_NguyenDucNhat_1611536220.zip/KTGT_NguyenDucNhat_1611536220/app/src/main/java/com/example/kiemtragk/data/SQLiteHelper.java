package com.example.kiemtragk.data;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.example.kiemtragk.model.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nhat on 27/8/19.
 */

public class SQLiteHelper extends SQLiteOpenHelper {
    private final String TAG = "SQLiteHelper";
    private static final String DATABASE_NAME = "Infor_Product";
    private static final String TABLE_NAME = "product";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String MFG_DATE = "mfg_date";
    private static final String ADDRESS = "address";
    private static final String EXP_DATE = "exp_date";
    private static final String IMGAGE = "image";
    private static final String PRICE = "price";
    private static int VERSION = 1;

    private Context context;
    private String SQLQuery = "CREATE TABLE " + TABLE_NAME + " (" +
            ID + " integer primary key, " +
            NAME + " TEXT, " +
            MFG_DATE + " TEXT, " +
            ADDRESS + " TEXT, " +
            EXP_DATE + " TEXT, " +
            IMGAGE + " TEXT, " +
            PRICE + " integer)";


    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
        Log.d(TAG, "SQLiteHelper: ");
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQLQuery);
        Log.d(TAG, "onCreate: ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.d(TAG, "onUpgrade: ");
    }

    public void addProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME, product.getTenSP());
        values.put(MFG_DATE, product.getNgaySX());
        values.put(ADDRESS, product.getNoiSX());
        values.put(EXP_DATE, product.getNgayHH());
        values.put(IMGAGE, product.getHinhSP());
        values.put(PRICE, product.getGia());

        db.insert(TABLE_NAME, null, values);
        db.close();
        Log.d(TAG, "add Product Successfuly");
    }

    public List<Product> getAllProduct() {
        List<Product> listProduct = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()) {
            do {
                Product student = new Product();
                student.setID(cursor.getInt(0));
                student.setTenSP(cursor.getString(1)+"");
                student.setNgaySX(cursor.getString(2));
                student.setNoiSX(cursor.getString(3));
                student.setNgayHH(cursor.getString(4));
                student.setHinhSP(cursor.getString(5));
                student.setGia(cursor.getInt(6));
                listProduct.add(student);

            } while (cursor.moveToNext());
        }
        db.close();
        return listProduct;
    }
    public int updateProduct(Product product){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME,product.getTenSP());
        contentValues.put(MFG_DATE,product.getNgaySX());
        contentValues.put(ADDRESS,product.getNoiSX());
        contentValues.put(EXP_DATE,product.getNgayHH());
        contentValues.put(IMGAGE,product.getHinhSP());
        contentValues.put(PRICE,product.getGia());
        return db.update(TABLE_NAME,contentValues,ID+"=?",new String[]{String.valueOf(product.getID())});
    }
    public int deleteProduct(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME,ID+"=?",new String[] {String.valueOf(id)});
    }
}

